package junho;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Letter implements ActionListener {

	private Client c;
	private JLabel letterHeader;
	private String letterId;
	private JTextArea letterArea;
	private Button replyBtn;
	private Button sendBtn;
	private JFrame letterFrame;
	public Letter(Client c) {
		this.c = c;
		letterFrame = new JFrame();
		letterFrame.setTitle("����");
		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension screen = tool.getScreenSize();
		Dimension letterSize = new Dimension(350, 250);
		letterFrame.setVisible(true);
		letterFrame.setSize(letterSize);
		letterFrame.setLocation((screen.width - letterFrame.getWidth()) / 6,
				(screen.height - letterFrame.getHeight()) / 6);
		letterFrame.setResizable(false);
		letterFrame.setLayout(new BorderLayout());
		JPanel jpSouth = new JPanel();
		JPanel jpCenter = new JPanel();
		JPanel jpNorth = new JPanel();
		jpNorth.setBackground(new Color(143, 171, 245));
		jpCenter.setBackground(new Color(185, 231, 255));
		jpSouth.setBackground(new Color(172, 216, 255));
		letterId = c.getLetterId();
		letterHeader = new JLabel("�޴� ��� : [" + letterId+"]", JLabel.LEFT);
		jpNorth.add(letterHeader);

		letterArea = new JTextArea(30, 30);
		letterArea.setLineWrap(true);
		jpCenter.add(letterArea);

		sendBtn = new Button("����");
		sendBtn.addActionListener(this);
		jpSouth.add(sendBtn);

		replyBtn = new Button("����");
		replyBtn.addActionListener(this);
		jpSouth.add(replyBtn);
		replyBtn.setEnabled(false);

		letterFrame.add(jpSouth, BorderLayout.SOUTH);
		letterFrame.add(jpNorth, BorderLayout.NORTH);
		letterFrame.add(jpCenter, BorderLayout.CENTER);
	}

	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == sendBtn) {
			String letterMsg = c.getId() + "##letter##" + letterArea.getText() + "##" + letterId;
			if (letterArea.getText() == null || letterArea.getText() == "") {
				JOptionPane.showMessageDialog(letterFrame, "�޼����� �Է����ּ���.", "error", JOptionPane.WARNING_MESSAGE);
			} else {
				try {
					c.getOos().writeObject(letterMsg);
					letterFrame.dispose();
				} catch (IOException e2) {
				}
			}
		} else if (obj == replyBtn) {
			Letter letter = new Letter(c);
			letter.letterId = this.letterId;
			letter.letterHeader.setText("�޴� ��� : [" + letterId+"]");
			letterFrame.dispose();
		}
	} //actionPerform end
	
	public JTextArea getLetterArea() {
		return letterArea;
	}
	
	public Button getReplyBtn() {
		return replyBtn;
	}
	
	public Button getSendBtn() {
		return sendBtn;
	}
	
	public JLabel getLetterHeader() {
		return letterHeader;
	}
	
	public void setLetterId (String letterId) {
		this.letterId = letterId;
	}
} //class end
