package junho;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.List;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Client implements ActionListener {

	private Socket socket;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private String ip = "localhost";
	private String id;
	private JFrame jframe;
	private TextField myChat;
	private JTextArea chatArea;
	private List memArea;
	private Label chatHead;
	private JScrollPane jpCenter;
	private JPanel jpSouth, jpNorth, jpEast, jpEastNorth;
	private Button btn;
	private Label memNum;
	private String letterId;
	private JTextArea letterArea;

	public Client() {
		Login login = new Login(this);
		// login�� init
		init(login);
		while (login.isDisplayable()){
			System.out.print("");
		}
		id = login.getUserId();

		jframe = new JFrame("��Ʈ��");
		myChat = new TextField(30);

		String imgAddress = "bitTalk.png";
		File file = new File(imgAddress);
		final Image img = new ImageIcon(imgAddress).getImage();

		
		chatArea = new JTextArea("",30,40){
			public void paint(Graphics g) {
				g.drawImage(img, 0, 0, null);
				super.paint(g);
			}
		};
		chatArea.setOpaque(false);
		Font font = new Font("",Font.PLAIN,16);
		chatArea.setFont(font);
		memArea = new List(40);
		memNum = new Label("���� ������ �� : ");
		memNum.setAlignment(Label.CENTER);
		Label letterHint = new Label("���̵� �ι����� ������ ��������");
		chatHead = new Label(id + "��, �ݰ����ϴ�!");
		// �ð踦 ���� ����ϱ����� ������ timeThr ����, �ٸ� �����尡 ��� ����Ǹ� �Բ� �������� Daemon������� ����
		Thread timeThr = new Thread(new Runnable() {
			public void run() {
				SimpleDateFormat sdf = new SimpleDateFormat("MM�� dd�� E���� hh:mm:ss aa");
				while (true) {
					chatHead.setText(id + "��, �ݰ����ϴ�! " + sdf.format(new Date()));
				}
			}
		});

		timeThr.setDaemon(true);
		timeThr.start();

		btn = new Button("����");

		jpSouth = new JPanel();
		jpNorth = new JPanel();
		jpCenter = new JScrollPane(chatArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		jpEast = new JPanel();
		jpEastNorth = new JPanel();
		jpEastNorth.setLayout(new GridLayout(2,1));

		jpSouth.setLayout(new BorderLayout());
		jpNorth.setLayout(new BorderLayout());
		jpEast.setLayout(new BorderLayout());

		jpSouth.add(btn, BorderLayout.EAST);
		jpSouth.add(myChat, BorderLayout.CENTER);
		jpNorth.add(chatHead, BorderLayout.CENTER);
		jpEast.add(memArea, BorderLayout.CENTER);
		jpEast.add(jpEastNorth, BorderLayout.NORTH);
		jpEastNorth.add(memNum);
		jpEastNorth.add(letterHint);

		jframe.add(jpSouth, BorderLayout.SOUTH);
		jframe.add(jpNorth, BorderLayout.NORTH);

		jframe.add(jpCenter, BorderLayout.CENTER);
		jframe.add(jpEast, BorderLayout.EAST);

		myChat.addActionListener(this);
		btn.addActionListener(this);
		memArea.addActionListener(this);

		jframe.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				try {
					oos.writeObject(id + "##exit");
				} catch (IOException e1) {
				}
				exit();
			}

			public void windowOpened(WindowEvent e) {
				myChat.requestFocus();
			}
		});

		// ������
		jpSouth.setBackground(new Color(217, 217, 243)); //���Ķ�
		jpNorth.setBackground(new Color(206, 239, 228)); //���ʷ�
		jpEastNorth.setBackground(new Color(157, 211, 168)); //�ʷ�
		chatArea.setBackground(new Color(252, 252, 252));
		memArea.setBackground(new Color(217, 217, 243)); //���Ķ�

		// chatArea �Ҵ�ȭ
		chatArea.setEditable(false);
		// �ڵ� ����
		chatArea.setLineWrap(true);
		// chatArea.setOpaque(true); //����� ������ �� �ִ� ����� ������ �� �ʿ�

		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension dim = tool.getScreenSize();
		int sh = dim.height;
		int sw = dim.width;

		// jframe �� ����� ������Ʈ���� �������� ������ ����
		jframe.pack();
		jframe.setLocation((sw - jframe.getWidth()) / 2, (sh - jframe.getHeight()) / 2);
		jframe.setResizable(false);
		jframe.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		String msg = myChat.getText();
		if (obj == myChat) {
			if (msg == null || msg.length() == 0) {
				JOptionPane.showMessageDialog(jframe, "�޼����� �Է����ּ���.", "error", JOptionPane.WARNING_MESSAGE);
			} else {
				try {
					oos.writeObject(id + "##message##" + msg);
				} catch (IOException e1) {
				}
				myChat.setText("");
			}
		} else if (obj == btn) {
			try {
				oos.writeObject(id + "##exit");
			} catch (IOException e1) {
			}
			exit();
		} else if (obj == memArea) {
			letterId = memArea.getItem(memArea.getSelectedIndex());
			if (letterId.equals(id)) {
				JOptionPane.showMessageDialog(jframe, "�ڱ� �ڽſ��Դ� �޼����� ���� �� �����ϴ�.", "error", JOptionPane.WARNING_MESSAGE);
			} else {
				new Letter(this);
			}
		}
	}

	public void exit() {
		try {
			if(ois!=null){ois.close();}
			System.out.println("ois close...");
			if(oos!=null){oos.close();}	
			System.out.println("oos close...");
			if(socket!=null){socket.close();}
			System.out.println("socket close...");
			
		} catch (IOException e) {
		}
		System.exit(0);
	}

	// Client Thread�� ���ڷ� �޾� Thread��ü ����, Thread ����
	public void init() {
		try {
			socket = new Socket(ip, 6000);
			System.out.println("ä�ü��� �����");
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
			ClientThread ct = new ClientThread(this);
			ct.start();
		} catch (UnknownHostException e) {
		} catch (IOException e) {
		}
	}

	// login�� init, ������ �����ε带 �̿��� ���� �α��� �����带 �������� �ʰ� Login��ü ������ �α��ξ��������� ä�þ���������
	// �Ǵ��ϰ���
	public void init(Login login) {
		try {
			socket = new Socket(ip, 6000);
			System.out.println("�α��μ��� �����");
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
			ClientThread clt = new ClientThread(this, login);
			clt.start();
		} catch (UnknownHostException e) {
		} catch (IOException e) {
		}
	}

	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		Client c = new Client();
		c.init();
	}

	public ObjectInputStream getOis() {
		return ois;
	}

	public JTextArea getChatArea() {
		return chatArea;
	}

	public List getMemArea() {
		return memArea;
	}

	public ObjectOutputStream getOos() {
		return oos;
	}

	public String getId() {
		return id;
	}

	public Label getMemNum() {
		return memNum;
	}

	public String getLetterId() {
		return letterId;
	}

	public JFrame getJframe() {
		return jframe;
	}
} // class end
