package day04;

public class korean implements People {
	private String name;
	private String SSN;
	
	public void eatKimchi() {
		System.out.println("��ġ�� �Դ´�.");
	}

	@Override
	public void speak() {
		System.out.println("�ѱ�� ���Ѵ�.");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eat() {
		System.out.println("��ġ�� �Դ´�.");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fight() {
		// TODO Auto-generated method stub
		
	}
}
